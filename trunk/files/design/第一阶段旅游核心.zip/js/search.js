$(function(){
//alert($("form p a:first").html())
$("form p a:first").addClass("currentSearchBg")							
$("form p a").click(function(){
$("form p a").removeClass("currentSearchBg")							
$(this).addClass("currentSearchBg")							
})































})